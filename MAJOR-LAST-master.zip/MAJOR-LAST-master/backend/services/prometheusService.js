/**
 * Prometheus Service – Collects and formats infrastructure metrics
 */

const axios = require("axios");
const Metric = require("../models/Metric");

const PROMETHEUS_URL =
  process.env.PROMETHEUS_URL || "http://prometheus:9090";

/**
 * Query Prometheus for a given PromQL expression.
 */
async function queryPrometheus(query, options = {}) {
  try {
    const { data } = await axios.get(`${PROMETHEUS_URL}/api/v1/query`, {
      params: { query },
    });

    if (data.status === "success" && data.data.result.length > 0) {
      const value = parseFloat(data.data.result[0].value[1]);
      return Number.isFinite(value) ? value : null;
    }

    return null;
  } catch (err) {
    if (!options.optional) {
      console.error(`[Prometheus] Query failed (${query}):`, err.message);
    }
    return null;
  }
}

/**
 * Collect a full metrics snapshot from Prometheus and persist to MongoDB.
 */
async function collectMetrics() {
  // ✅ FIXED CPU QUERY (robust & correct)
  const cpu = await queryPrometheus(
    'sum(rate(node_cpu_seconds_total{mode!="idle"}[1m])) * 100'
  );

  const memory = await queryPrometheus(
    '(1 - node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes) * 100'
  );

  const disk = await queryPrometheus(
    '(1 - node_filesystem_avail_bytes{mountpoint="/"} / node_filesystem_size_bytes{mountpoint="/"}) * 100'
  );

  const latency = await queryPrometheus(
    'avg(scrape_duration_seconds{job="node-exporter"}) * 1000'
  );

  const podRestarts =
    (await queryPrometheus(
      "sum(kube_pod_container_status_restarts_total)",
      { optional: true }
    )) ?? 0;

  // ❗ Do NOT fake values — skip if missing
  if (cpu === null ) {
    console.warn("[Prometheus] Missing required metrics; skipping snapshot");
    return null;
  }
  const safeMemory = memory ?? 0;
const safeDisk = disk ?? 0;
const safeLatency = latency ?? 0;

  const metricsData = {
  cpu_usage: parseFloat(Math.max(cpu, 0).toFixed(2)),
  memory_usage: parseFloat(safeMemory.toFixed(2)),
  disk_usage: parseFloat(safeDisk.toFixed(2)),
  network_latency: parseFloat(safeLatency.toFixed(2)),
  pod_restarts: Math.max(0, Math.round(podRestarts)),
  source: "prometheus",
};

  await Metric.create(metricsData);

  console.log("📊 Metrics collected:", metricsData); // ✅ debug log

  return metricsData;
}

/**
 * Return formatted Prometheus-style metrics for the /metrics endpoint.
 */
async function getFormattedMetrics() {
  const latest = await Metric.findOne().sort({ createdAt: -1 });

  if (!latest) return "# No metrics collected yet\n";

  return [
    `# HELP outage_sense_cpu_usage Current CPU usage percentage`,
    `# TYPE outage_sense_cpu_usage gauge`,
    `outage_sense_cpu_usage ${latest.cpu_usage}`,

    `# HELP outage_sense_memory_usage Current memory usage percentage`,
    `# TYPE outage_sense_memory_usage gauge`,
    `outage_sense_memory_usage ${latest.memory_usage}`,

    `# HELP outage_sense_disk_usage Current disk usage percentage`,
    `# TYPE outage_sense_disk_usage gauge`,
    `outage_sense_disk_usage ${latest.disk_usage}`,

    `# HELP outage_sense_network_latency Current network latency in ms`,
    `# TYPE outage_sense_network_latency gauge`,
    `outage_sense_network_latency ${latest.network_latency}`,

    `# HELP outage_sense_pod_restarts Pod restart count`,
    `# TYPE outage_sense_pod_restarts gauge`,
    `outage_sense_pod_restarts ${latest.pod_restarts}`,
  ].join("\n") + "\n";
}

module.exports = {
  collectMetrics,
  getFormattedMetrics,
  queryPrometheus,
};
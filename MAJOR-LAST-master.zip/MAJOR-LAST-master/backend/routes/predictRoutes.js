const express = require("express");
const router = express.Router();
const mlService = require("../services/mlService");

// ─────────────────────────────────────────────
// 🔮 POST /api/predict
// Send metrics to ML service for prediction
// ─────────────────────────────────────────────
router.post("/", async (req, res) => {
  try {
    console.log("📥 Received /api/predict request");
    console.log("📊 Payload:", req.body);

    const results = await mlService.predict(req.body);

    console.log("📤 ML Response:", results);

    if (!results || results.length === 0) {
      console.warn("⚠️ ML returned empty results");
    }

    res.json({
      success: true,
      predictions: results,
    });
  } catch (err) {
    console.error("❌ Prediction error:", err.message);

    res.status(500).json({
      success: false,
      error: err.message,
    });
  }
});

// ─────────────────────────────────────────────
// 🧠 POST /api/predict/train
// Trigger model training
// ─────────────────────────────────────────────
router.post("/train", async (_req, res) => {
  try {
    console.log("⚙️ Training model via API...");

    const result = await mlService.train();

    console.log("✅ Training completed:", result);

    res.json({
      success: true,
      training_summary: result,
    });
  } catch (err) {
    console.error("❌ Training error:", err.message);

    res.status(500).json({
      success: false,
      error: err.message,
    });
  }
});

// ─────────────────────────────────────────────
// 🩺 GET /api/predict/health
// Check ML service health
// ─────────────────────────────────────────────
router.get("/health", async (_req, res) => {
  try {
    console.log("🔍 Checking ML service health...");

    const health = await mlService.checkHealth();

    console.log("✅ ML Health:", health);

    res.json({
      success: true,
      ml_service: health,
    });
  } catch (err) {
    console.error("❌ Health check error:", err.message);

    res.status(500).json({
      success: false,
      error: err.message,
    });
  }
});

module.exports = router;
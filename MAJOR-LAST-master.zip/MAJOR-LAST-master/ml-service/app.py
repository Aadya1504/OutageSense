"""
Outage Sense ML Flask API
Endpoints: POST /train, POST /predict, GET /health
"""

import os
import time
import traceback

import pandas as pd
import requests
from flask import Flask, jsonify, request
from flask_cors import CORS

from generate_dataset import OUTPUT_PATH, generate_dataset
from model import FEATURE_COLUMNS, get_model, predict, train_model

app = Flask(__name__)
CORS(app)

# 🔥 Slack cooldown config
SLACK_COOLDOWN_SECONDS = int(os.environ.get("SLACK_COOLDOWN_SECONDS", "60"))
last_slack_alert_at = 0


# ───────────────────────────────────────────────────────────────
# ✅ Ensure model exists
# ───────────────────────────────────────────────────────────────
def ensure_model_ready():
    if get_model() is not None:
        return

    print("⚙️ No trained model found. Training automatically...")

    if not os.path.exists(OUTPUT_PATH):
        generate_dataset()

    data = pd.read_csv(OUTPUT_PATH)
    train_model(data, contamination=0.01)

    print("✅ Model trained and ready.")


# ───────────────────────────────────────────────────────────────
# 🚨 Slack Alert (FIXED + DEBUG)
# ───────────────────────────────────────────────────────────────
def send_slack_alert(message):
    global last_slack_alert_at

    webhook_url = os.environ.get("SLACK_WEBHOOK_URL")

    if not webhook_url:
        print("❌ SLACK_WEBHOOK_URL not set — cannot send alert")
        return

    now = time.time()

    if now - last_slack_alert_at < SLACK_COOLDOWN_SECONDS:
        print("⏳ Slack cooldown active — skipping alert")
        return

    try:
        print("📨 Sending Slack alert...")

        response = requests.post(
            webhook_url,
            json={"text": message},
            timeout=5,
        )

        print("Slack response status:", response.status_code)
        print("Slack response text:", response.text)

        response.raise_for_status()

        last_slack_alert_at = now
        print("✅ Slack alert sent successfully")

    except Exception as exc:
        print("❌ Slack alert failed:", exc)


# ───────────────────────────────────────────────────────────────
# 🩺 Health check
# ───────────────────────────────────────────────────────────────
@app.route("/health", methods=["GET"])
def health():
    return jsonify(
        {
            "status": "healthy",
            "service": "outage-sense-ml",
            "model_loaded": get_model() is not None,
        }
    )


# ───────────────────────────────────────────────────────────────
# 🧠 Train endpoint
# ───────────────────────────────────────────────────────────────
@app.route("/train", methods=["POST"])
def train():
    try:
        body = request.get_json(silent=True) or {}
        contamination = body.get("contamination", 0.01)
        regenerate = body.get("regenerate_dataset", False)

        if regenerate or not os.path.exists(OUTPUT_PATH):
            generate_dataset()

        data = pd.read_csv(OUTPUT_PATH)
        result = train_model(data, contamination=contamination)

        return jsonify({"success": True, "training_summary": result}), 200

    except Exception as exc:
        traceback.print_exc()
        return jsonify({"success": False, "error": str(exc)}), 500


# ───────────────────────────────────────────────────────────────
# 🔮 Predict endpoint
# ───────────────────────────────────────────────────────────────
@app.route("/predict", methods=["POST"])
def predict_route():
    try:
        body = request.get_json()
        if body is None:
            return jsonify({"success": False, "error": "Request body must be JSON"}), 400

        records = body if isinstance(body, list) else [body]

        # Validate fields
        for record in records:
            missing = [f for f in FEATURE_COLUMNS if f not in record]
            if missing:
                return jsonify({"success": False, "error": f"Missing fields: {missing}"}), 400

        ensure_model_ready()

        # 🔥 Run prediction
        results = predict(pd.DataFrame(records))

        # 🔥 DEBUG: print predictions
        print("📊 Predictions:", results)

        anomalies = [r for r in results if r["prediction"] == "anomaly"]

        if anomalies:
            print("🚨 Anomaly detected — triggering Slack")

            first = anomalies[0]

            send_slack_alert(
                "🚨 *Anomaly Detected!*\n"
                f"CPU: {first['cpu_usage']}%\n"
                f"Memory: {first['memory_usage']}%\n"
                f"Disk: {first['disk_usage']}%\n"
                f"Latency: {first['network_latency']} ms\n"
                f"Restarts: {first['pod_restarts']}\n"
                f"Score: {first.get('anomaly_score', 'N/A')}"
            )
        else:
            print("✅ No anomaly detected")

        return jsonify({"success": True, "predictions": results}), 200

    except Exception as exc:
        traceback.print_exc()
        return jsonify({"success": False, "error": str(exc)}), 500


# ───────────────────────────────────────────────────────────────
# 🚀 Auto-train on startup
# ───────────────────────────────────────────────────────────────
ensure_model_ready()


# ───────────────────────────────────────────────────────────────
# ▶️ Run server
# ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    port = int(os.environ.get("ML_SERVICE_PORT", 5001))
    debug = os.environ.get("FLASK_DEBUG", "false").lower() == "true"

    app.run(host="0.0.0.0", port=port, debug=debug)
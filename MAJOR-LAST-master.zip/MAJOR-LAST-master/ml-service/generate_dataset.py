import os

import numpy as np
import pandas as pd


OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "data")
OUTPUT_PATH = os.path.join(OUTPUT_DIR, "metrics_dataset.csv")
ANOMALIES_PATH = os.path.join(OUTPUT_DIR, "anomalies_test.csv")


def generate_dataset(n_normal: int = 5000, n_anomalous: int = 250):
    np.random.seed(42)

    normal = pd.DataFrame(
        {
            "cpu_usage": np.random.uniform(8, 68, n_normal),
            "memory_usage": np.random.uniform(18, 72, n_normal),
            "disk_usage": np.random.uniform(15, 76, n_normal),
            "network_latency": np.random.uniform(5, 180, n_normal),
            "pod_restarts": np.random.randint(0, 3, n_normal),
        }
    )

    anomalous = pd.DataFrame(
        {
            "cpu_usage": np.random.uniform(86, 100, n_anomalous),
            "memory_usage": np.random.uniform(86, 100, n_anomalous),
            "disk_usage": np.random.uniform(91, 100, n_anomalous),
            "network_latency": np.random.uniform(1001, 2500, n_anomalous),
            "pod_restarts": np.random.randint(6, 50, n_anomalous),
        }
    )

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    normal.to_csv(OUTPUT_PATH, index=False)
    anomalous.to_csv(ANOMALIES_PATH, index=False)

    print(f"Training dataset saved: {OUTPUT_PATH} ({len(normal)} normal rows)")
    print(f"Anomaly test dataset saved: {ANOMALIES_PATH} ({len(anomalous)} rows)")

    return normal

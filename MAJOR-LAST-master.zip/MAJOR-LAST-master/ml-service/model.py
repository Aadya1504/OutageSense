"""
Outage Sense ML model module.
Isolation Forest with feature scaling plus hard safety thresholds.
"""

import os

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler


MODEL_DIR = os.path.join(os.path.dirname(__file__), "models")
MODEL_PATH = os.path.join(MODEL_DIR, "isolation_forest.pkl")

FEATURE_COLUMNS = [
    "cpu_usage",
    "memory_usage",
    "disk_usage",
    "network_latency",
    "pod_restarts",
]


def get_model():
    """Load the trained model and scaler from disk, or return None."""
    if not os.path.exists(MODEL_PATH):
        return None

    artifact = joblib.load(MODEL_PATH)
    if isinstance(artifact, tuple) and len(artifact) == 2:
        return artifact

    # Old single-model artifacts are intentionally ignored so the service retrains.
    return None


def train_model(data: pd.DataFrame, contamination: float = 0.01):
    """Train on normal metrics only and persist the model with its scaler."""
    os.makedirs(MODEL_DIR, exist_ok=True)

    contamination = min(max(float(contamination), 0.01), 0.02)
    X = data[FEATURE_COLUMNS].astype(float).values

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    model = IsolationForest(
        n_estimators=200,
        contamination=contamination,
        max_samples="auto",
        random_state=42,
        n_jobs=1,
    )
    model.fit(X_scaled)
    joblib.dump((model, scaler), MODEL_PATH)

    scores = model.decision_function(X_scaled)
    predictions = model.predict(X_scaled)

    return {
        "samples_trained": int(len(X)),
        "anomalies_found": int((predictions == -1).sum()),
        "contamination": contamination,
        "mean_score": float(np.mean(scores)),
        "model_path": MODEL_PATH,
    }


def _result(row, prediction, score, reason):
    return {
        "cpu_usage": float(row["cpu_usage"]),
        "memory_usage": float(row["memory_usage"]),
        "disk_usage": float(row["disk_usage"]),
        "network_latency": float(row["network_latency"]),
        "pod_restarts": int(row["pod_restarts"]),
        "prediction": prediction,
        "anomaly_score": float(score),
        "reason": reason,
    }


def predict(data: pd.DataFrame):
    """Predict anomalies for incoming metrics."""
    artifact = get_model()
    if artifact is None:
        raise FileNotFoundError("Model not trained yet.")

    model, scaler = artifact
    results = []

    for _, row in data[FEATURE_COLUMNS].astype(float).iterrows():
        cpu = row["cpu_usage"]
        mem = row["memory_usage"]
        disk = row["disk_usage"]
        latency = row["network_latency"]
        restarts = row["pod_restarts"]

        if cpu > 85 or mem > 85 or disk > 90 or latency > 1000 or restarts > 5:
            results.append(_result(row, "anomaly", -1.0, "rule_override"))
            continue

        if cpu < 70 and mem < 75 and disk < 80 and latency < 200 and restarts < 3:
            results.append(_result(row, "normal", 0.0, "normal_threshold"))
            continue

        X = np.array([[cpu, mem, disk, latency, restarts]])
        X_scaled = scaler.transform(X)
        prediction = model.predict(X_scaled)[0]
        score = model.decision_function(X_scaled)[0]

        results.append(
            _result(
                row,
                "anomaly" if prediction == -1 else "normal",
                score,
                "isolation_forest",
            )
        )

    return results
